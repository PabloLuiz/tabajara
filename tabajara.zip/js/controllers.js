angular.module('app.controllers', [])
  
.controller('webRuthinhaLoginCtrl', function($scope) {

})
      
.controller('eTECRuthCardosoCtrl', function($scope) {

})
   
.controller('cadastroCtrl', function($scope) {

})
   
.controller('registradoCtrl', function($scope) {

})
 